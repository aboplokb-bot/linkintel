// ============================================================
// LINKINTEL — /api/process route
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import { processMediaJob } from '@/app/server/jobProcessor';
import { ProcessRequest } from '@/app/types';

export const maxDuration = 300; // 5 min timeout (Vercel Pro)
export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as ProcessRequest;

    if (!body.url) {
      return NextResponse.json({ success: false, error: 'URL is required.' }, { status: 400 });
    }

    const result = await processMediaJob(body);

    if (!result.success) {
      return NextResponse.json(result, { status: 422 });
    }

    return NextResponse.json(result);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Internal server error.';
    console.error('[LINKINTEL] Process error:', error);
    return NextResponse.json({ success: false, error: msg }, { status: 500 });
  }
}
